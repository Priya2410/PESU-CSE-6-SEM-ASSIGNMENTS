#include<stdio.h>
#include<iostream>
int a = 10;
int b = 20;
//Input COmment
/*Multi Line
COmment
Here*/
int main(){
	char str1;
	float val1;
	int c=100, d=200;
	c = 50;
}