#include<stdio.h>
main(){ 
    int a=10;
    int b,x,z;
    int sum=a+b;
    printf("Sum=%d",sum);
    printf("hello world");
    return 0;
}
